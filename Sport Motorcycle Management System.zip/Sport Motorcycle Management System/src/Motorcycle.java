/*
 * Name: Aubrey Soule
 * Date: May 8,2026
 * Assignment: Course Project
 * Description: Abstract base class for all motorcycles
 */

public abstract class Motorcycle {

    private String brand;
    private String model;
    private int engineSize;
    private int topSpeed;

    // Constructor
    protected Motorcycle(String brand, String model, int engineSize, int topSpeed) {
        this.brand = brand;
        this.model = model;
        this.engineSize = engineSize;
        this.topSpeed = topSpeed;
    }

    // Getters and Setters
    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }

    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    public int getEngineSize() { return engineSize; }
    public void setEngineSize(int engineSize) { this.engineSize = engineSize; }

    public int getTopSpeed() { return topSpeed; }
    public void setTopSpeed(int topSpeed) { this.topSpeed = topSpeed; }

    // Abstract method (polymorphism)
    public abstract void displayInfo();
}