/*
 * Name: Aubrey Soule
 * Date: May 8, 2026
 * Assignment: Course Project
 * Description:
 * This class manages the SQLite database for the
 * Sport Motorcycle Management System. It performs
 * CRUD operations using JDBC.
 */

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MotorcycleDB implements DatabaseOperations {

    private Connection conn;

    public MotorcycleDB() {

        try {

            conn = DriverManager.getConnection(
                    "jdbc:sqlite:motorcycles.db");

            createTable();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private void createTable() {

        String sql =
                "CREATE TABLE IF NOT EXISTS motorcycles (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "brand TEXT," +
                "model TEXT," +
                "engine_size INTEGER," +
                "top_speed INTEGER," +
                "manufacturer TEXT," +
                "type TEXT," +
                "cylinder_count INTEGER" +
                ");";

        try (Statement stmt = conn.createStatement()) {

            stmt.execute(sql);

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    @Override
    public void createMotorcycle(SportMotorcycle moto) {

        String sql =
                "INSERT INTO motorcycles " +
                "(brand, model, engine_size, top_speed, " +
                "manufacturer, type, cylinder_count) " +
                "VALUES(?,?,?,?,?,?,?)";

        try (PreparedStatement pstmt =
                     conn.prepareStatement(sql)) {

            pstmt.setString(1, moto.getBrand());
            pstmt.setString(2, moto.getModel());
            pstmt.setInt(3, moto.getEngine().getEngineSize());
            pstmt.setInt(4, moto.getTopSpeed());
            pstmt.setString(5, moto.getManufacturer());
            pstmt.setString(6, moto.getType());
            pstmt.setInt(7,
                    moto.getEngine().getCylinderCount());

            pstmt.executeUpdate();

            System.out.println(
                    "Motorcycle added to database.");

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    @Override
    public List<SportMotorcycle> getMotorcycles() {

        List<SportMotorcycle> list = new ArrayList<>();

        String sql = "SELECT * FROM motorcycles";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {

                Engine engine = new Engine(
                        rs.getInt("engine_size"),
                        rs.getInt("cylinder_count")
                );

                SportMotorcycle moto =
                        new SportMotorcycle(
                                rs.getString("brand"),
                                rs.getString("model"),
                                rs.getInt("engine_size"),
                                rs.getInt("top_speed"),
                                rs.getString("manufacturer"),
                                rs.getString("type"),
                                engine
                        );

                moto.setId(rs.getInt("id"));

                list.add(moto);
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return list;
    }

    @Override
    public void updateMotorcycle(
            int id,
            SportMotorcycle moto) {

        String sql =
                "UPDATE motorcycles SET " +
                "brand=?, " +
                "model=?, " +
                "engine_size=?, " +
                "top_speed=?, " +
                "manufacturer=?, " +
                "type=?, " +
                "cylinder_count=? " +
                "WHERE id=?";

        try (PreparedStatement pstmt =
                     conn.prepareStatement(sql)) {

            pstmt.setString(1, moto.getBrand());
            pstmt.setString(2, moto.getModel());
            pstmt.setInt(3,
                    moto.getEngine().getEngineSize());
            pstmt.setInt(4, moto.getTopSpeed());
            pstmt.setString(5, moto.getManufacturer());
            pstmt.setString(6, moto.getType());
            pstmt.setInt(7,
                    moto.getEngine().getCylinderCount());

            pstmt.setInt(8, id);

            pstmt.executeUpdate();

            System.out.println(
                    "Motorcycle updated.");

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    @Override
    public void deleteMotorcycle(int id) {

        String sql =
                "DELETE FROM motorcycles WHERE id=?";

        try (PreparedStatement pstmt =
                     conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            pstmt.executeUpdate();

            System.out.println(
                    "Motorcycle deleted.");

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
}
