/*
 * Name: Aubrey
 * Date: April 26,2026
 * Assignment: Course Project
 * Description: A Sport Motorcycle
 */

public class SportMotorcycle extends Motorcycle {

    private int id;
    private String manufacturer;
    private String type;
    private Engine engine; // Composition

    // Constructor
    public SportMotorcycle(String brand, String model, int engineSize, int topSpeed,
                           String manufacturer, String type, Engine engine) {
        super(brand, model, engineSize, topSpeed);
        this.manufacturer = manufacturer;
        this.type = type;
        this.engine = engine;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getManufacturer() { return manufacturer; }
    public void setManufacturer(String manufacturer) { this.manufacturer = manufacturer; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public Engine getEngine() { return engine; }
    public void setEngine(Engine engine) { this.engine = engine; }

    // Polymorphism (override)
    @Override
    public void displayInfo() {
        System.out.println(toString());
    }

    @Override
    public String toString() {
        return "ID: " + id +
                "\nMotorcycle: " + getBrand() + " " + getModel() +
               "\nEngine: " + engine +
               "\nTop Speed: " + getTopSpeed() + " mph" +
               "\nManufacturer: " + manufacturer +
               "\nType: " + type;
    }
}