/*
 * Name: Aubrey Soule
 * Date: May 8,2026
 * Assignment: Course Project
 * Description: Main Application
 */

import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        MotorcycleDB db = new MotorcycleDB();

        int choice;

        do {
            System.out.println("\nWelcome to Speed-FO!!");
            System.out.println("\nYour Sport Motorcycle Info System\n");
            System.out.println("1. Add Motorcycle");
            System.out.println("2. View Motorcycles");
            System.out.println("3. Update Motorcycle");
            System.out.println("4. Delete Motorcycle");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");

            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {

                case 1:
                    System.out.print("Brand: ");
                    String brand = scanner.nextLine();

                    System.out.print("Model: ");
                    String model = scanner.nextLine();

                    System.out.print("Engine Size (cc): ");
                    int engineSize = scanner.nextInt();

                    System.out.print("Top Speed: ");
                    int topSpeed = scanner.nextInt();

                    System.out.print("Cylinder Count: ");
                    int cylinders = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Manufacturer: ");
                    String manufacturer = scanner.nextLine();

                    System.out.print("Type: ");
                    String type = scanner.nextLine();

                    Engine engine = new Engine(engineSize, cylinders);
                    SportMotorcycle moto = new SportMotorcycle(
                            brand, model, engineSize, topSpeed,
                            manufacturer, type, engine
                    );

                    db.createMotorcycle(moto);
                    break;

                case 2:
                    for (SportMotorcycle m : db.getMotorcycles()) {
                        m.displayInfo();
                    }
                    break;

                case 3:

                    System.out.print("Enter Motorcycle ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("New Brand: ");
                    String newBrand = scanner.nextLine();

                    System.out.print("New Model: ");
                    String newModel = scanner.nextLine();

                    System.out.print("New Engine Size: ");
                    int newEngineSize = scanner.nextInt();

                    System.out.print("New Top Speed: ");
                    int newTopSpeed = scanner.nextInt();

                    System.out.print("New Cylinder Count: ");
                    int newCylinders = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("New Manufacturer: ");
                    String newManufacturer = scanner.nextLine();

                    System.out.print("New Type: ");
                    String newType = scanner.nextLine();

                    Engine updatedEngine = new Engine(newEngineSize, newCylinders);

                    SportMotorcycle updatedMoto = new SportMotorcycle(
                            newBrand,
                            newModel,
                            newEngineSize,
                            newTopSpeed,
                            newManufacturer,
                            newType,
                            updatedEngine
                    );

                    db.updateMotorcycle(updateId, updatedMoto);

                    break;

                case 4:
                    System.out.print("Enter id to delete: ");
                    int id = scanner.nextInt();
                    db.deleteMotorcycle(id);
                    break;
            }

        } while (choice != 5);

        scanner.close();
    }
}