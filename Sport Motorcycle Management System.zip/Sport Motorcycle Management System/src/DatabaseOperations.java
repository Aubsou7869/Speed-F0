/*
 * Name: Aubrey Soule
 * Date: May 8,2026
 * Assignment: Course Project
 * Description: Interface
 */

import java.util.List;

public interface DatabaseOperations {

    void createMotorcycle(SportMotorcycle moto);

    List<SportMotorcycle> getMotorcycles();

    void updateMotorcycle(int id, SportMotorcycle moto);

    void deleteMotorcycle(int id);
}