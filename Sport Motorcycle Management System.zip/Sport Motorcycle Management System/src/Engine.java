/*
 * Name: Aubrey Soule
 * Date: May 8,2026
 * Assignment: Course Project
 * Description: Engine info
 */

public class Engine {

    private int engineSize;
    private int cylinderCount;

    // Constructor
    public Engine(int engineSize, int cylinderCount) {
        this.engineSize = engineSize;
        this.cylinderCount = cylinderCount;
    }

    // Getters and Setters
    public int getEngineSize() { return engineSize; }
    public void setEngineSize(int engineSize) { this.engineSize = engineSize; }

    public int getCylinderCount() { return cylinderCount; }
    public void setCylinderCount(int cylinderCount) { this.cylinderCount = cylinderCount; }

    @Override
    public String toString() {
        return engineSize + "cc, " + cylinderCount + " cylinders";
    }
}